"""
Defence Opportunity Intelligence — API foundation.

Phase 0, revised after first live run: reads real config from the
environment (was hardcoded before), and adds the signup/login
routes that were missing — without these, there was no way to
create a tenant/user or obtain a real token to test anything
beyond /healthz.
"""

import os
from datetime import datetime, timedelta, timezone
from typing import Optional

import jwt
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, EmailStr
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker

# ---------------------------------------------------------------
# Config — now actually read from the environment docker-compose
# sets, with sane local-dev fallbacks. Previously these were
# hardcoded literals that silently diverged from docker-compose.yml.
# ---------------------------------------------------------------
DATABASE_URL = os.environ.get(
    "DATABASE_URL", "postgresql+asyncpg://doi_app:changeme@localhost:5432/doi"
)
JWT_SECRET = os.environ.get("JWT_SECRET", "dev-secret-change-in-real-deploys")
JWT_ALGO = "HS256"
ACCESS_TOKEN_MINUTES = 30

engine = create_async_engine(DATABASE_URL, echo=False)
SessionLocal = async_sessionmaker(engine, expire_on_commit=False)
ph = PasswordHasher()

app = FastAPI(title="Defence Opportunity Intelligence API")
bearer_scheme = HTTPBearer()


# ---------------------------------------------------------------
# Auth
# ---------------------------------------------------------------
class TokenPayload(BaseModel):
    sub: str          # user id
    tenant_id: str
    role: str
    exp: datetime


def create_access_token(user_id: str, tenant_id: str, role: str) -> str:
    payload = {
        "sub": user_id,
        "tenant_id": tenant_id,
        "role": role,
        "exp": datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_MINUTES),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)


def decode_token(token: str) -> TokenPayload:
    try:
        data = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGO])
        return TokenPayload(**data)
    except jwt.PyJWTError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired token")


async def get_current_user(
    creds: HTTPAuthorizationCredentials = Depends(bearer_scheme),
) -> TokenPayload:
    return decode_token(creds.credentials)


async def get_tenant_session(user: TokenPayload = Depends(get_current_user)):
    async with SessionLocal() as session:
        await session.execute(
            text("select set_config('app.current_tenant', :tid, true)"),
            {"tid": user.tenant_id},
        )
        try:
            yield session
        finally:
            await session.close()


def require_role(*allowed_roles: str):
    async def checker(user: TokenPayload = Depends(get_current_user)):
        if user.role not in allowed_roles:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Insufficient role for this action")
        return user
    return checker


async def write_audit_log(
    session: AsyncSession,
    tenant_id: str,
    user_id: Optional[str],
    action: str,
    entity_type: str,
    entity_id: Optional[str],
    before: Optional[dict],
    after: Optional[dict],
):
    await session.execute(
        text("""
            insert into audit_log
                (tenant_id, user_id, action, entity_type, entity_id, before_state, after_state)
            values
                (:tenant_id, :user_id, :action, :entity_type, :entity_id, :before, :after)
        """),
        {
            "tenant_id": tenant_id, "user_id": user_id, "action": action,
            "entity_type": entity_type, "entity_id": entity_id,
            "before": before, "after": after,
        },
    )


# ---------------------------------------------------------------
# Signup / Login — the piece that was missing. Signup creates a
# tenant AND its first user (an admin) in one call, since there's
# no such thing as a user without a tenant in this model.
# ---------------------------------------------------------------
class SignupIn(BaseModel):
    company_name: str
    email: EmailStr
    password: str


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"


@app.post("/auth/signup", response_model=TokenOut, status_code=201)
async def signup(body: SignupIn):
    if len(body.password) < 10:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Password must be at least 10 characters")

    password_hash = ph.hash(body.password)

    async with SessionLocal() as session:
        existing = await session.execute(
            text("select id from users where email = :email"), {"email": body.email}
        )
        if existing.first():
            raise HTTPException(status.HTTP_409_CONFLICT, "An account with this email already exists")

        tenant_result = await session.execute(
            text("insert into tenants (name) values (:name) returning id"),
            {"name": body.company_name},
        )
        tenant_id = tenant_result.scalar_one()

        admin_role = await session.execute(text("select id from roles where name = 'admin'"))
        admin_role_id = admin_role.scalar_one()

        user_result = await session.execute(
            text("""
                insert into users (tenant_id, email, password_hash, role_id)
                values (:tenant_id, :email, :password_hash, :role_id)
                returning id
            """),
            {
                "tenant_id": str(tenant_id), "email": body.email,
                "password_hash": password_hash, "role_id": str(admin_role_id),
            },
        )
        user_id = user_result.scalar_one()

        await session.execute(
            text("select set_config('app.current_tenant', :tid, true)"),
            {"tid": str(tenant_id)},
        )
        await write_audit_log(
            session, str(tenant_id), str(user_id), "tenant.created_via_signup",
            "tenant", str(tenant_id), None, {"company_name": body.company_name},
        )
        await session.commit()

    token = create_access_token(str(user_id), str(tenant_id), "admin")
    return TokenOut(access_token=token)


@app.post("/auth/login", response_model=TokenOut)
async def login(body: LoginIn):
    async with SessionLocal() as session:
        result = await session.execute(
            text("""
                select u.id, u.tenant_id, u.password_hash, r.name as role_name
                from users u join roles r on r.id = u.role_id
                where u.email = :email and u.is_active = true
            """),
            {"email": body.email},
        )
        row = result.first()

    if row is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid email or password")

    try:
        ph.verify(row.password_hash, body.password)
    except VerifyMismatchError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid email or password")

    token = create_access_token(str(row.id), str(row.tenant_id), row.role_name)
    return TokenOut(access_token=token)


# ---------------------------------------------------------------
# Example tenant-scoped routes — unchanged in logic, now actually
# reachable since doi_app has real grants and signup/login exist.
# ---------------------------------------------------------------
class ProductIn(BaseModel):
    name: str
    description: Optional[str] = None
    trl: Optional[int] = None


@app.post("/products", status_code=201)
async def create_product(
    body: ProductIn,
    user: TokenPayload = Depends(require_role("admin", "analyst")),
    session: AsyncSession = Depends(get_tenant_session),
):
    result = await session.execute(
        text("""
            insert into products (tenant_id, name, description, trl, created_by)
            values (:tenant_id, :name, :description, :trl, :created_by)
            returning id
        """),
        {
            "tenant_id": user.tenant_id, "name": body.name,
            "description": body.description, "trl": body.trl, "created_by": user.sub,
        },
    )
    new_id = result.scalar_one()
    await write_audit_log(
        session, user.tenant_id, user.sub, "product.created",
        "product", str(new_id), None, body.model_dump(),
    )
    await session.commit()
    return {"id": str(new_id)}


@app.get("/products")
async def list_products(
    user: TokenPayload = Depends(get_current_user),
    session: AsyncSession = Depends(get_tenant_session),
):
    result = await session.execute(text("select id, name, trl, created_at from products"))
    return [dict(row._mapping) for row in result]


@app.get("/healthz")
async def healthz():
    return {"status": "ok"}

