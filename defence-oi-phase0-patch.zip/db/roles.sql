-- The application connects as this role, never as `postgres`.
-- RLS policies apply to it; a superuser bypasses RLS entirely,
-- which would silently defeat the tenant-isolation guarantee.

create extension if not exists citext;

do $$
begin
    if not exists (select from pg_catalog.pg_roles where rolname = 'doi_app') then
        create role doi_app with login password 'changeme';
    end if;
end
$$;

grant connect on database doi to doi_app;
