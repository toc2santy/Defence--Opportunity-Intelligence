"""
Phase 1 — real Capability Intelligence classification.

This replaces the prototype's throwaway logic:

    def classify(t):
        for k in CAPABILITY_LIBRARY:      # 11 hardcoded strings
            if k in t: return CAPABILITY_LIBRARY[k]   # first match wins

with weighted, scored, multi-candidate matching against a real,
extensible taxonomy table — and every result carries the evidence
(which keywords matched, at what weight) instead of just a label.

Deliberately NOT machine learning. This is Option A from the
Phase 1 design decision: fully deterministic and explainable,
which matters more than raw pattern-catching power when the buyer
is a defence procurement team who will ask "why did it classify
this way" and expects a real answer.
"""

import re
from typing import TypedDict

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

# Score thresholds — deliberately conservative. A single generic
# weight-1 keyword match should not produce a "high confidence"
# classification; it takes either one strong (weight-3) term plus
# a supporting one, or multiple corroborating terms.
HIGH_CONFIDENCE_THRESHOLD = 6
MEDIUM_CONFIDENCE_THRESHOLD = 3
MINIMUM_SCORE_TO_SUGGEST = 2  # below this, don't bother suggesting at all


class Candidate(TypedDict):
    capability_id: str
    code: str
    label: str
    sector: str
    score: int
    matched_keywords: list[str]
    confidence: str


async def _load_taxonomy_keywords(session: AsyncSession):
    result = await session.execute(
        text("""
            select k.capability_id, c.code, c.label, c.sector, k.keyword, k.weight
            from capability_taxonomy_keywords k
            join capability_taxonomy c on c.id = k.capability_id
        """)
    )
    return result.all()


def score_text(input_text: str, taxonomy_rows) -> list[Candidate]:
    """
    Pure function, no I/O — this is what gets unit-tested directly
    without needing a database. `taxonomy_rows` is a list of
    (capability_id, code, label, sector, keyword, weight) tuples.
    """
    normalized = input_text.lower()
    scores: dict[str, Candidate] = {}

    for capability_id, code, label, sector, keyword, weight in taxonomy_rows:
        # Word-boundary match so "ai" doesn't match inside "maintain",
        # and multi-word phrases like "electronic warfare" match as
        # a unit rather than any substring appearance.
        pattern = r"\b" + re.escape(keyword.lower()) + r"\b"
        if re.search(pattern, normalized):
            key = str(capability_id)
            if key not in scores:
                scores[key] = {
                    "capability_id": key,
                    "code": code,
                    "label": label,
                    "sector": sector,
                    "score": 0,
                    "matched_keywords": [],
                    "confidence": "low",
                }
            scores[key]["score"] += weight
            scores[key]["matched_keywords"].append(keyword)

    candidates = sorted(scores.values(), key=lambda c: c["score"], reverse=True)
    for c in candidates:
        if c["score"] >= HIGH_CONFIDENCE_THRESHOLD:
            c["confidence"] = "high"
        elif c["score"] >= MEDIUM_CONFIDENCE_THRESHOLD:
            c["confidence"] = "medium"
        else:
            c["confidence"] = "low"
    return candidates


async def classify_text(session: AsyncSession, input_text: str) -> list[Candidate]:
    """DB-backed entry point the API calls."""
    rows = await _load_taxonomy_keywords(session)
    return score_text(input_text, rows)
