"""
This is the one test in the whole suite that requires something I
could not verify myself: a real, live SAM.gov API key. It is
skipped automatically unless SAM_GOV_API_KEY is set in the
environment — so `pytest -v` continues to pass cleanly without it,
and this only runs when you deliberately opt in.

To actually run this test:
    export SAM_GOV_API_KEY=your_real_key
    pytest tests/test_sam_gov_live.py -v

This is the first genuine test of whether fetch_opportunities()
actually works against the real API — everything else in Phase 2
was verified against documented schema, not a live round-trip.
"""

import os
import pytest


pytestmark = pytest.mark.skipif(
    not os.environ.get("SAM_GOV_API_KEY"),
    reason="SAM_GOV_API_KEY not set — skipping live SAM.gov API test. "
           "Set it and re-run to actually verify the live connector.",
)


def test_ingestion_endpoint_runs_against_real_sam_gov(client, auth_headers):
    """
    Note: this hits the REAL SAM.gov API through your API container,
    which must ALSO have SAM_GOV_API_KEY set in its own environment
    (docker-compose.yml / .env), not just in your shell running pytest.
    Uses a narrow NAICS code and short window to conserve your daily
    rate limit (personal keys: ~10 requests/day).
    """
    resp = client.post(
        "/ingestion/sam-gov/run",
        headers=auth_headers,
        json={"naics_codes": ["334511"], "days_back": 30},
    )
    assert resp.status_code == 200, f"ingestion failed: {resp.text}"
    body = resp.json()

    assert "job_id" in body
    assert "records_ingested" in body
    print(f"\nLive SAM.gov ingestion: {body['records_ingested']} records ingested")
    if body["errors"]:
        print(f"Errors encountered: {body['errors']}")
    if body["failures"]:
        print(f"Records that failed to normalize: {len(body['failures'])}")

    # A successful call should produce a job row we can look up
    jobs_resp = client.get("/ingestion/jobs", headers=auth_headers)
    assert jobs_resp.status_code == 200
    jobs = jobs_resp.json()
    assert any(j["id"] == body["job_id"] for j in jobs)
