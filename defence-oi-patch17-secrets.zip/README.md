# Defence Opportunity Intelligence — Engineering Status

This document reflects what's actually built and verified as of
Phase 3, not the original aspirational brief. Every claim below has
been run against a real database, a real API, and — where noted —
a real external government data source. Where something is a known
gap or limitation, it's stated plainly rather than glossed over;
that discipline is what makes the rest of this document trustworthy.

## What's real vs. what's still aspirational

The original product brief described ten intelligence engines. As
of this writing:

| Engine | Status |
|---|---|
| Capability Intelligence | **Real.** Weighted keyword taxonomy, human-confirmed, evidence-backed. |
| Market Intelligence | **Partial.** Real for U.S. federal (SAM.gov). India (SRIJAN/iDEX) has no public API — unsolved, see below. |
| Programme Intelligence | **Real.** NAICS + keyword matching, self-corrected once against real false positives. |
| Customer Intelligence | Not started (Phase 4). |
| OEM & Partner Matching | Not started (Phase 4). |
| Competitor Intelligence | Not started (Phase 4). |
| Opportunity Intelligence | **Real**, but only as the direct output of Programme Intelligence matching — no independent scoring model beyond that yet. |
| Procurement Intelligence | **Real**, folded into the SAM.gov ingestion (opportunity stage, deadlines). |
| Engagement Intelligence | Not started. |
| Next-Best-Action | Not started. |

The original marketing site prototype's "engine" logic (an 11-line
keyword table, hash-based fake scores) has been fully superseded by
the code below wherever a phase covers the same ground. Where a
phase hasn't been reached yet, the prototype UI is still
disconnected from anything real — don't mistake it for coverage.

## Architecture

**Database**: PostgreSQL. Tenant-owned data (`products`,
`opportunities`, `product_capabilities`, `audit_log`) is isolated
via Row-Level Security — enforced at the database connection level,
not by application code remembering a `WHERE tenant_id = ...`
clause. Shared reference data (`programmes`, `organizations`,
`markets`, `capability_taxonomy`, `sources`, `evidence`) has no
tenant scoping by design — every tenant benefits from the same
ingested market/programme intelligence.

**API**: FastAPI, JWT auth, Argon2 password hashing. Every route
that touches tenant data sets the Postgres session's tenant context
before querying, which RLS then enforces.

**Evidence model**: nothing in this system claims a fact without a
traceable source. Every classification, every ingested programme,
every match carries a `source_id`, a `confidence` level
(`high`/`medium`/`low`), and an `evidence_status`
(`verified`/`reported`/`estimated`/`ai_inferred`/`unverified`).
This is enforced by schema, not just UI copy.

**Human-in-the-loop**: AI-suggested capability classifications
(`classified_by = 'ai_suggested'`) are never used for programme
matching until an analyst explicitly confirms them
(`classified_by = 'analyst'`). This gate is enforced in the
matching query itself, not just described as a workflow.

## What's actually built, phase by phase

### Phase 0 — Foundation
17-table schema, tenancy, RBAC, audit logging, source/evidence
framework. Signup/login with real password hashing. Verified with
a full automated test suite, not just manual `curl` checks.

### Phase 1 — Capability Intelligence
`POST /products/{id}/classify` — weighted keyword matching against
an extensible `capability_taxonomy` (20 sectors, ~100 seeded
keywords), replacing the prototype's 11-entry hardcoded lookup.
Every classification stores which keywords matched and at what
score — genuinely explainable, not a black-box label.
`POST /products/{id}/capabilities/{cap_id}/confirm` and
`.../reject` implement the human-in-the-loop gate.

### Phase 2 — Market & Programme Data (SAM.gov)
`POST /ingestion/sam-gov/run` — real, live ingestion from the U.S.
government's public Contract Opportunities API. Verified against
GSA's own documented example responses for the parsing logic, and
against the actual live API for the full round-trip (100 real
federal opportunities ingested and confirmed present in the
database during this project).

**India (SRIJAN/iDEX) has no public API** — confirmed by direct
research, not assumed. This is not an engineering gap to "fix
later" — it's a fundamentally different problem (licensed data
partnership or manual analyst entry via the schema's existing
`customer_provided`/`internal_analyst` source types) that needs a
business decision, not more code.

**SAM.gov API key expiry is tracked in the database**, not just
remembered by a person. `GET /ingestion/sam-gov/key-status` reports
days remaining; every `/ingestion/sam-gov/run` response includes
the current status automatically. `PATCH /ingestion/sam-gov/key-status`
updates it after a key rotation. Personal-tier keys are rate
limited to roughly 10 requests/day — ingestion defaults to 3 NAICS
codes per run to stay well under that.

### Phase 3 — Programme Matching
`POST /products/{id}/match-programmes` — connects a product's
CONFIRMED capabilities to real ingested programmes via two combined
signals: a curated NAICS-to-taxonomy mapping, and a keyword
re-score of the programme's own title. This is the first code in
the project that populates the `opportunities` table, which existed
in the schema since Phase 0 but was never written to until now.

**Self-corrected once already, on real evidence**: the first live
run surfaced genuine false positives (programmes sharing a NAICS
code with a product but zero actual textual relevance — e.g. "GPS
HATCH SYSTEMS" matching a radar product on category alone). The
scoring logic was fixed so a NAICS-only match with no keyword
corroboration can never be labeled better than "low confidence" —
a real finding from real data, not a hypothetical worth worrying
about later.

### Scheduled Ingestion + "What's New" (the real "early achiever" mechanism)

A deliberate detour from the numbered roadmap, prompted by a
grounding question worth recording: does knowing *who won* a
government contract actually help a defense SME sell their product?
Honest answer: not much, on its own — and claiming "you won because
of us" would be a causally overreaching claim this platform has no
basis to make. What genuinely *is* provable, and actually useful, is
**visibility timing**: did you find out about a real opportunity
earlier than you otherwise would have?

That's what this piece implements, concretely:

- **`scheduled_sam_gov_ingestion`** runs automatically on a timer
  (`SCHEDULED_INGESTION_INTERVAL_HOURS`, default 24) via APScheduler,
  registered on API startup — ingestion no longer depends on anyone
  remembering to trigger it manually.
- **`GET /opportunities/new`** — returns only opportunities created
  since the tenant last checked, then advances a server-side
  checkpoint (`tenants.opportunities_last_viewed_at`). The tenant
  never writes to that checkpoint directly, which is what makes "you
  saw this first" a provable timestamp rather than a marketing line.
  `?mark_seen=false` allows peeking without advancing it.
- **`GET /ingestion/scheduler-status`** — confirms the job is
  genuinely registered and shows its next run time.

Customer/OEM/Competitor Intelligence (the original roadmap's Phase 4)
was deliberately deferred in favor of this — reasoned through
explicitly rather than just following the numbered plan, on the
grounds that it doesn't answer a real user's actual daily question
("what should I act on today") the way this does.

## Running it locally

```bash
cp .env.example .env
# fill in JWT_SECRET (generate with: python3 -c "import secrets; print(secrets.token_urlsafe(48))")
# leave SAM_GOV_API_KEY blank unless you're running live ingestion

docker compose up --build
# API on http://localhost:8000, Postgres on localhost:5432

# apply migrations in order, against a fresh or existing DB:
docker compose exec -T db psql -U postgres -d doi < db/migrations/002_capability_keywords.sql
docker compose exec -T db psql -U postgres -d doi < db/migrations/003_ingestion_sam_gov.sql
docker compose exec -T db psql -U postgres -d doi < db/migrations/004_programme_matching.sql
docker compose exec -T db psql -U postgres -d doi < db/migrations/005_api_credentials.sql
docker compose exec -T db psql -U postgres -d doi < db/migrations/006_scheduled_ingestion_and_notifications.sql
```

To actually ingest real data, get a free SAM.gov Public API Key
(SAM.gov → Account Details) and set `SAM_GOV_API_KEY` before
starting Docker.

## Migrations

Managed with Alembic (`api/alembic/`). Each revision is a thin
wrapper that reads and executes the corresponding raw `.sql` file
under `db/migrations/` — those files remain the actual source of
truth for what each migration does; Alembic adds version tracking,
`upgrade`/`downgrade` orchestration, and a real `alembic_version`
table, instead of everyone remembering by hand which numbered
`.sql` file they last ran manually.

**On a database that already has this schema applied** (true for
this project's own dev database, since the six migrations were
originally applied by hand before Alembic was adopted) — tell
Alembic the current state without re-running anything. Run this
inside the already-running API container, not from your host shell
— it already has Alembic installed and the correct `DATABASE_URL`
for the Docker network, so there's nothing extra to configure:

```bash
docker compose exec api alembic stamp 0006_scheduled_ingestion
```

**On a genuinely fresh, empty database** — run everything from
scratch:

```bash
docker compose exec api alembic upgrade head
```

**Going forward, once there's an actual schema change to make**:

```bash
docker compose exec api alembic revision -m "add competitor_awards table"
# hand-write the upgrade()/downgrade() in the new file under alembic/versions/
# (it'll appear in ./api/alembic/versions/ on your host too, since
# the api/ folder is not copied-once but part of your normal project files)
docker compose exec api alembic upgrade head
```

**No autogenerate** (`alembic revision --autogenerate`) — this
project has no declarative SQLAlchemy ORM models to diff against
(queries are raw SQL via `text()`), so every migration is hand-
written, same as the raw `.sql` files it replaces. This is a
deliberate, honest limitation stated once here rather than
discovered by surprise later.

**Migrations run under a different, more privileged database role
than the app itself** (`ALEMBIC_DATABASE_URL`, defaulting to
`postgres` in local dev — see `docker-compose.yml` and
`alembic/env.py`). The running API connects as `doi_app`, a role
deliberately granted no `CREATE` privilege on the schema — real
least-privilege, not just RLS. Migrations genuinely need
schema-altering rights, so rather than weaken `doi_app`'s grants to
get there, they run under a separate credential instead. This was
discovered, not designed upfront in the abstract: the first real
`alembic stamp` attempt failed with a permissions error trying to
create the `alembic_version` table as `doi_app` — exactly the
least-privilege boundary working as intended, not a bug.

**Downgrades are honest, not decorative.** Several `downgrade()`
functions deliberately do less than a perfect mirror of their
`upgrade()` — e.g. `0003` and `0004` leave `programmes.naics_code`
and the seeded SAM.gov source row in place even on downgrade,
because by the time anyone runs one, real ingested programme data
depends on them, and silently stripping that out would be a data
loss bug hiding inside a "revert this migration" command. Each one
says exactly what it does and doesn't undo, in a comment, rather
than pretending symmetry it doesn't have.

## Testing

```bash
cd api
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
pytest -v
```

53 tests, 1 intentionally skipped (the live SAM.gov integration
test, which only runs when `SAM_GOV_API_KEY` is set — everything
else runs without any external credentials or network access).

Split deliberately into pure unit tests (no DB, no network — the
scoring/normalization/matching *logic* itself) and integration
tests (hit the real running stack over HTTP, no mocking). This
split has already caught bugs the other kind wouldn't have: DB
permission grants, a jsonb serialization quirk, a SQLAlchemy `::`
cast parsing gotcha, and a UUID type mismatch in an audit log call
— none of which a mocked-DB test would have surfaced, because they
only appeared when real SQL hit a real Postgres instance.

## Known limitations — stated plainly, not hidden

- **India market coverage does not exist.** No public API for
  SRIJAN/iDEX was found. This needs a licensed-data or manual-entry
  decision, not an engineering fix.
- **The NAICS-to-taxonomy mapping is a curated v1 starting set**
  (`db/migrations/004_programme_matching.sql`), not a finished,
  domain-expert-reviewed taxonomy. It will both miss real matches
  and occasionally over-match until someone with real defense
  procurement classification expertise reviews and extends it.
- **SAM.gov is U.S. federal-prime only.** No state, local,
  education, or non-U.S. procurement coverage.
- **The scheduler only runs while the API process is running.** On
  a laptop that's only up during dev sessions, "scheduled" is
  theoretical, not actually happening in the background. This needs
  a genuinely always-on deployment (a real server, not local Docker)
  before the "you saw this first" claim is true in practice, not
  just true in the code.
- **"What's new" tracking is per-tenant, not per-user.** If multiple
  people share one tenant login, one person checking marks it seen
  for everyone. Fine for now; worth revisiting once multi-user
  tenants are a real usage pattern.
- ~~No Alembic migration history~~ — **resolved.** See "Migrations"
  below. The old hand-numbered `db/migrations/*.sql` files are kept
  as-is and still the actual source of truth for what each
  migration does; Alembic revisions wrap them rather than
  duplicating their content, so there's one copy of each migration's
  SQL, not two that could silently drift apart.
- **`JWT_SECRET` is now properly managed via a git-ignored `.env`
  file**, generated randomly rather than a checked-in placeholder —
  this was the most security-sensitive secret in the whole system,
  since leaking it lets anyone forge a valid login token for any
  tenant without ever touching the database. **The Postgres
  passwords (`doi_app`, `postgres` superuser) are still hardcoded**
  in `db/roles.sql` and `docker-compose.yml` — acceptable for now
  because the database port is only reachable on localhost in this
  local-only setup, but this genuinely must be fixed before any real
  deployment where that port might be reachable from anywhere else.
- **Customer/OEM/Competitor Intelligence (the original roadmap's
  Phase 4) is deliberately deferred**, not forgotten — reasoned
  through explicitly (see above) rather than built reflexively
  because it was next in a numbered list.

## Why RLS instead of just filtering in application code

A `WHERE tenant_id = :tenant_id` clause in every query works right
up until one route forgets it — and in a codebase with dozens of
routes, that's a `when`, not an `if`. Postgres RLS makes the tenant
boundary a property of the database connection itself: even a buggy
or malicious query literally cannot return another tenant's rows,
because Postgres filters them out before the application ever sees
them. This has been independently verified twice — once by hand
(a second tenant genuinely could not see a first tenant's product)
and once automatically (the test suite asserts it on every run).
