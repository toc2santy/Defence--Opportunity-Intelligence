"""
Pure combination logic for Phase 3 matching — no I/O, same
separation pattern as app/scoring.py (Phase 1). Combines two
independent signals into one score:

  1. A NAICS-to-taxonomy mapping match (a curated table lookup —
     coarse but fast, and grounded in official government
     classification)
  2. A keyword re-score of the programme's own title against that
     specific capability's keyword set (reuses Phase 1's scoring
     engine) — this is what filters out the false positives a
     NAICS-only match lets through, e.g. a "GNSS dredging system"
     programme sharing a NAICS code with genuine UAV/sensor work
     despite having nothing to do with either.
"""

from typing import TypedDict

NAICS_MATCH_BONUS = 3
HIGH_CONFIDENCE_THRESHOLD = 6
MEDIUM_CONFIDENCE_THRESHOLD = 3
MAX_SCORE = 100  # matches the opportunities.score check constraint (0-100)


class CombinedScore(TypedDict):
    total_score: int
    confidence: str


def combine_score(naics_match: bool, keyword_score: int) -> CombinedScore:
    total = (NAICS_MATCH_BONUS if naics_match else 0) + keyword_score
    total = min(total, MAX_SCORE)

    if total >= HIGH_CONFIDENCE_THRESHOLD:
        confidence = "high"
    elif total >= MEDIUM_CONFIDENCE_THRESHOLD:
        confidence = "medium"
    else:
        confidence = "low"

    return {"total_score": total, "confidence": confidence}
