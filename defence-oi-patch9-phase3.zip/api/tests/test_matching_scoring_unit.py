"""
Unit tests for app.matching_scoring.combine_score — no DB, no
network. Same standalone-verification discipline used for
app.scoring and app.sam_gov_normalize: every assertion here was
run directly before being committed to this file.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.matching_scoring import combine_score, NAICS_MATCH_BONUS, MAX_SCORE


def test_naics_only_match():
    r = combine_score(naics_match=True, keyword_score=0)
    assert r["total_score"] == NAICS_MATCH_BONUS
    assert r["confidence"] == "medium"  # 3 >= medium threshold


def test_keyword_only_no_naics():
    r = combine_score(naics_match=False, keyword_score=5)
    assert r["total_score"] == 5
    assert r["confidence"] == "medium"


def test_both_signals_combine_additively():
    r = combine_score(naics_match=True, keyword_score=5)
    assert r["total_score"] == 8
    assert r["confidence"] == "high"


def test_weak_signal_is_low_confidence():
    r = combine_score(naics_match=False, keyword_score=1)
    assert r["total_score"] == 1
    assert r["confidence"] == "low"


def test_no_signal_at_all():
    r = combine_score(naics_match=False, keyword_score=0)
    assert r["total_score"] == 0
    assert r["confidence"] == "low"


def test_score_never_exceeds_max():
    # this matters because opportunities.score has a real database
    # check constraint (0-100) — an uncapped score here would crash
    # the insert, not just look wrong
    r = combine_score(naics_match=True, keyword_score=999)
    assert r["total_score"] == MAX_SCORE
